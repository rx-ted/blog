# theme-example
文章 [从零开始制作 Hexo 主题](http://www.ahonn.me/2016/12/15/create-a-hexo-theme-from-scratch/) 中的 Hexo 主题例子。