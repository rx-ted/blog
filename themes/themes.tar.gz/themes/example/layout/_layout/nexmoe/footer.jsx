const { Component, Fragment } = require('inferno');

module.exports = class extends Component {
    render() {
        // const { body } = this.props;

        return (
            <Fragment></Fragment>
        );
    }
};
